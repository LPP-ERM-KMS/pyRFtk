Usage
==================================
Installation
---------------------------------
To install the program you'll just have to move to go to the folder "dist" and run 

.. code-block:: console

        (.venv) $pip install pyrftk2-2.0.0-py3-none-any.whl

A simple circuit
---------------------------------


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
