.. pyRFtk documentation master file, created by
   sphinx-quickstart on Tue Sep 12 14:19:33 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pyRFtk's documentation!
==================================
**pyRFtk** is a Python library to build and analyse RF circuits in the MHz range, especially designed
for ICRH antennae

.. note::
   This project is under active development.

Contents
--------
.. toctree::
        usage


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
