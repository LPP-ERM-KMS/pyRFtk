Logging
=============

.. code-block::
    from pyRFtk.config import setLogLevel
