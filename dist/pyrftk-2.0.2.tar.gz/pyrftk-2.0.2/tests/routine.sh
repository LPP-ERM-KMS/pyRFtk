python tests.py
cd "/home/arthur/BigFiles/Arc Detection/launcher/"
python Launcher.py
