Arc Detection
=============
