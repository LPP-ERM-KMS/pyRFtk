Welcome to pyRFtk's documentation!
==================================
**pyRFtk** is a Python library which can be used to build and analyse RF circuits, it was originally designed
for ICRH antennae but is now made widely deployable.

.. note::
   This project is under active development.

Contents
--------
.. toctree::
        usage
        TOMAS


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
