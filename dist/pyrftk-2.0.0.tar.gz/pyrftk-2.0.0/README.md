# pyRFtk

## About

pyRFtk is a Python library able to build and analyse RF circuits in the MHz range, especially designed for ICRH antennae.

## Authors
The code was mainly developed by RF-engineer Frederic Durodie and later
on refactored, packaged and documented by Arthur Adriaens
